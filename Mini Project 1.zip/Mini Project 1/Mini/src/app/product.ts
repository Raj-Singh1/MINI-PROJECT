export class Product{
    ProdId:number;
    ProdName:string;
    ProdDes:string;
    ProdPrice:number;
}