import { Component } from '@angular/core';
import { Book } from './book';
import { BookService } from './app.bookservice'
@Component({
    selector: 'book-app',
    templateUrl: './app.book.html',
    styleUrls: ['./app.book.css'],
    providers: [BookService]
})

export class BookComponent {

    p: number = 1;
    model: any = {};
    up: any = {};
    Books: Book[];
    constructor(private getAllBooks: BookService) { }  
    ngOnInit(): any {
        this.getAllBooks.getAllBooks().subscribe((data: Book[]) => this.Books = data);
    }

    addDetails(): any {

        this.Books.push(this.model)
        this.model = {};
    }


    update(eid: number): any {
        for (let i in this.Books) {
            if (this.Books[i].id == eid) {
                this.up = this.Books[i];
            }

        }


    }
    updatenew(): any {
        this.up.id = (document.getElementById("a") as HTMLInputElement).value;
        this.up.title = (document.getElementById("b") as HTMLInputElement).value;
        this.up.author = (document.getElementById("c") as HTMLInputElement).value;
        this.up.year = (document.getElementById("d") as HTMLInputElement).value;

        this.up = {}
    }
    delete(eid: number): any {
        for (let i in this.Books) {
            if (this.Books[i].id == eid) {
                this.Books.splice(Number(i), 1);
            }

        }
    }
    deleteAll(): any {


        this.Books.splice(0, this.Books.length);
    }


}

