import { Component, OnInit } from '@angular/core';
import {Productservice} from './productservice';
import { Product } from '../product';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  //template:'',
  styleUrls: ['./product.component.css'],
  providers:[Productservice]
})
export class ProductComponent implements OnInit {
  products:Product[];
  model:any={};
  constructor(private _productservice:Productservice) { }

  ngOnInit() {
    this._productservice.getAllProduct().subscribe((data:Product[])=>this.products=data);
  }
  delete(i:number):any{    
    return this.products.splice(i,1);
  }
  edit(pro:Product):any{
    

  }
  addProduct(){
 
    this.products.push(this.model);
   
    
  }
   closeSelf(){
    
    alert("conditions satisfied, submiting the form.");
    
}

}
