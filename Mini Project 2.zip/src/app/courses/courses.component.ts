import { Component, OnInit } from '@angular/core';
import { Courses } from '../courses';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
  coursesArr: Courses[] = [
    { id: 1, courseName: "HTML", coursePrice: 100, courseDuration: 15 },
    { id: 2, courseName: "CSS", coursePrice: 100, courseDuration: 25 },
    { id: 3, courseName: "Bootstrap", coursePrice: 100, courseDuration: 35 }
  ]
  courseObj: Courses = new Courses()
  courseObj1: Courses = new Courses()
  temp:number=0
  temp2:number=0
  Duration:string
  constructor() { }

  ngOnInit() {
  }
  AddCourse() {
    if (!this.courseObj.courseName || !this.courseObj.courseDuration) {
      return (this.temp=1,this.temp2=0)
    }
    else {
      this.temp=0
      this.temp2=0
      this.coursesArr.push(this.courseObj)
      this.courseObj = new Courses()
    }
  }
  getDuration() {
    this.coursesArr.map(x => {
      if (x.courseName.toLowerCase() == this.courseObj1.courseName.toLowerCase()) {
        this.Duration="The Duration of " + this.courseObj1.courseName + " is " + x.courseDuration+" days"
      }
    })
    this.temp2=2
    this.courseObj1 = new Courses()
  }

}
