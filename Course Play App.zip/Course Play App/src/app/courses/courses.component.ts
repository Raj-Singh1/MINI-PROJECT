import { Component, OnInit } from '@angular/core';
import { Courses } from '../courses';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})

export class CoursesComponent implements OnInit {
  coursesArr: Courses[] = [];
  courseObj: Courses = new Courses();
  courseObj1: Courses = new Courses();
  flag:number=0;
  DurationMsg:string;
  Update:string;

  constructor( private courseService:CourseService) { }

  ngOnInit() {
    this.courseService.getCourse().subscribe((course:Courses[])=>this.coursesArr=course)
  }

  UpdateCourse(){
    if (!this.courseObj.courseName || !this.courseObj.courseDuration) {
      return this.flag=1;
    }
    else if(this.courseObj.courseName)
    {
      this.flag=10;
      this.coursesArr.map(data => {
        if (data.courseName.toLowerCase() == this.courseObj.courseName.toLowerCase())
        {
          this.courseService.updateCourse(this.courseObj);
          this.courseService.getCourse().subscribe((course:Courses[])=>this.coursesArr=course);
          this.flag++;
          this.Update="You have updated the existing value";
          this.courseObj = new Courses();
        }
      })
    if(this.flag==10) {
      this.flag++;
      this.Update="You can't add new value here, please click ADD button"   
      }
    }
  }

  AddCourse() {
    if (!this.courseObj.courseName || !this.courseObj.courseDuration) {
      return this.flag=1;
    }
    else if(this.courseObj.courseName)
    {
      this.flag=10;
      this.coursesArr.map(data => {
        if (data.courseName.toLowerCase() == this.courseObj.courseName.toLowerCase())
        {
          this.flag++;
          this.Update="You cannot add the existing value. Please click on update button for updation.";
        }
      })
    if(this.flag==10) {
          this.courseService.AddCourse(this.courseObj);
          this.courseService.getCourse().subscribe((course:Courses[])=>this.coursesArr=course);   
      }
      this.courseObj = new Courses();
    }
  }

  getDuration() {
    if(this.courseObj1.courseName)
    {this.DurationMsg="The Course Name is inivalid";
    this.coursesArr.map(data => {
      if (data.courseName.toLowerCase() == this.courseObj1.courseName.toLowerCase()) {
        this.DurationMsg="The Duration of "+data.courseName+" is " + data.courseDuration+" days";
      }
    })
  }
    else
    {
      this.DurationMsg="The Course Name is not mentioned";
    }
    this.courseObj1 = new Courses();
  }
}