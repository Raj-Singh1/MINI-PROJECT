export class Courses {
    id:number
    courseName:string
    courseDuration:number
}
